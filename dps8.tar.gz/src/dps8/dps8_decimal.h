void ad2d (void);
void ad3d (void);
void sb2d (void);
void sb3d (void);
void mp2d (void);
void mp3d (void);
void dv2d (void);
void dv3d (void);
void cmpn (void);
void mvn (void);


