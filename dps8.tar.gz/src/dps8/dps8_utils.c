/**
 * \file dps8_utils.c
 * \project dps8
 * \date 9/25/12
 * \copyright Copyright (c) 2012 Harry Reed. All rights reserved.
*/

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "dps8.h"
#include "dps8_cpu.h"
#include "dps8_utils.h"
#include "dps8_opcodetable.h"
#include "dps8_faults.h"

/*
 * misc utility routines used by simulator
 */

//I_HEX I_ABS I_MIIF I_TRUNC  I_NBAR	I_PMASK I_PAR	 I_TALLY I_OMASK  I_EUFL	 I_EOFL	I_OFLOW	I_CARRY	    I_NEG	 I_ZERO
char * dumpFlags(word18 flags)
{
    static char buffer[256] = "";
    
    sprintf(buffer, "%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s",
            flags & I_HEX   ? "Hex "   : "",
            flags & I_ABS   ? "Abs "   : "",
            flags & I_MIIF  ? "Miif "  : "",
            flags & I_TRUNC ? "Trunc " : "",
            flags & I_NBAR	? "~BAR "  : "",
            flags & I_PMASK ? "PMask " : "",
            flags & I_PERR  ? "PErr"   : "",
            flags & I_TALLY ? "Tally " : "",
            flags & I_OMASK ? "OMASK " : "",
            flags & I_EUFL  ? "EUFL "  : "",
            flags & I_EOFL  ? "EOFL "  : "",
            flags & I_OFLOW	? "Ovr "   : "",
            flags & I_CARRY	? "Carry " : "",
            flags & I_NEG   ? "Neg "   : "",
            flags & I_ZERO  ? "Zero "  : ""
            );
    return buffer;
    
}

static char * strupr(char *str)
{
    char *s;
    
    for(s = str; *s; s++)
        *s = (char) toupper((unsigned char)*s);
    return str;
}

//extern char *opcodes[], *mods[];
//extern struct opCode NonEISopcodes[0100], EISopcodes[01000];

//! get instruction info for IWB ...

static opCode UnImp = {"(unimplemented)", 0, 0, 0};

struct opCode *getIWBInfo(DCDstruct *i)
{
    opCode *p;
    
    if (i->opcodeX == false)
        p = &NonEISopcodes[i->opcode];
    else
        p = &EISopcodes[i->opcode];
    
    if (p->mne == 0)
    {
#ifndef QUIET_UNUSED
        int r = 1;
#endif
    }
    
    return p->mne ? p : &UnImp;
}

char *disAssemble(word36 instruction)
{
    int32 opcode  = GET_OP(instruction);   ///< get opcode
    int32 opcodeX = GET_OPX(instruction);  ///< opcode extension
    a8    address = GET_ADDR(instruction);
    int32 a       = GET_A(instruction);
    //int32 i       = GET_I(instruction);
    int32 tag     = GET_TAG(instruction);

    static char result[132] = "???";
    strcpy(result, "???");
    
    // get mnemonic ...
    // non-EIS first
    if (!opcodeX)
    {
        if (NonEISopcodes[opcode].mne)
            strcpy(result, NonEISopcodes[opcode].mne);
    }
    else
    {
        // EIS second...
        if (EISopcodes[opcode].mne)
            strcpy(result, EISopcodes[opcode].mne);
        
        if (EISopcodes[opcode].ndes > 0)
        {
            // XXX need to reconstruct multi-word EIS instruction.

        }
    }
    
    char buff[64];
    
    if (a)
    {
        int n = (address >> 15) & 07;
        int offset = address & 077777;
    
        sprintf(buff, " pr%d|%o", n, offset);
        strcat (result, buff);
        // return strupr(result);
    } else {
        sprintf(buff, " %06o", address);
        strcat (result, buff);
    }
    // get mod
    strcpy(buff, "");
    for(int n = 0 ; n < 0100 ; n++)
        if (extMods[n].mod)
            if(n == tag)
            {
                strcpy(buff, extMods[n].mod);
                break;
            }

    if (strlen(buff))
    {
        strcat(result, ",");
        strcat(result, buff);
    }
    
    return strupr(result);
}

/*
 * getModString ()
 *
 * Convert instruction address modifier tag to printable string
 * WARNING: returns pointer to statically allocated string
 *
 */

char *getModString(int32 tag)
{
    static char msg[256];
    strcpy(msg, "none");
    
    if (tag >= 0100)
    {
        sprintf(msg, "getModReg(tag out-of-range %o)", tag);
    } else {
        for(int n = 0 ; n < 0100 ; n++)
            if (extMods[n].mod)
                if(n == tag)
                {
                    strcpy(msg, extMods[n].mod);
                    break;
                }

    }
    return msg;
}


/*
 * 36-bit arithmetic stuff ...
 */
/* Single word integer routines */


// XXX ticket #3 isSigned
// CANFAULT
word36 AddSub36b(char op, bool __attribute__((unused)) isSigned, word36 op1, word36 op2, word18 flagsToSet, word18 *flags)
{
    word36 res = 0;
    op1 &= ZEROEXT;
    op2 &= ZEROEXT;
        
    // perform requested operation
    bool overflow = false;
    
    switch (op)
    {
        case '+':
            res = op1 + op2;
            overflow = ((~(op1 ^ op2)) & (op1 ^ res) & 0x800000000);
            break;
        case '-':
            res = op1 - op2;
            //op2 = (1 + ~op2) & DMASK;
            //res = op1 + op2;
            overflow = ((~(op1 ^ ~op2)) & (op1 ^ res) & 0x800000000);
            break;
            // XXX make provisions for logicals
    }
    
       // now let's set some flags...
    
    // carry
    // NB: CARRY is not an overflow!
    
    if (flagsToSet & I_CARRY)
    {
        /* const */  bool carry = (res > 0xfffffffff);
if (op == '-') carry = ! carry; // XXX CAC black magic
        if (carry)
            SETF(*flags, I_CARRY);
        else
            CLRF(*flags, I_CARRY);
    }
    
    
    
    /*
     oVerflow rules .....
     
     oVerflow occurs for addition if the operands have the
     same sign and the result has a different sign. MSB(a) = MSB(b) and MSB(r) <> MSB(a)
     
     oVerflow occurs for subtraction if the operands have
     different signs and the sign of the result is different from the
     sign of the first operand. MSB(a) <> MSB(b) and MSB(r) <> MSB(a)
     */
    if (flagsToSet & I_OFLOW)
    {
        if (overflow)
            SETF(*flags, I_OFLOW);      // overflow
    }
    
    if (flagsToSet & I_ZERO)
    {
        if ((res & DMASK) == 0)
            SETF(*flags, I_ZERO);       // zero result
        else
            CLRF(*flags, I_ZERO);
    }
    
    if (flagsToSet & I_NEG)
    {
        if (res & SIGN36)            // if negative (things seem to want this even if unsigned ops)
            SETF(*flags, I_NEG);
        else
            CLRF(*flags, I_NEG);
    }
    
    if (flagsToSet & I_OFLOW)
    {
        if (overflow && ! TSTF (*flags, I_OMASK))
        {
            doFault(overflow_fault, 0,"addsub36b overflow fault");
        }
    }

    return res & DMASK;           // 64 => 36-bit. Mask off unnecessary bits ...
}

// XXX ticket #3 isSigned
// CANFAULT
word18 AddSub18b(char op, bool __attribute__((unused)) isSigned, word18 op1, word18 op2, word18 flagsToSet, word18 *flags)
{
    word18 res = 0;
    op1 &= ZEROEXT18;
    op2 &= ZEROEXT18;
    //word18 op1 = SIGNEXT18(oP1);
    //word18 op2 = SIGNEXT18(oP2);
    
    // perform requested operation
    bool overflow = false;
    
    switch (op)
    {
        case '+':
            res = op1 + op2;
            overflow = ((~(op1 ^ op2)) & (op1 ^ res) & SIGN18);
            break;
        case '-':
            res = op1 - op2;
            //op2 = (1 + ~op2) & DMASK;
            //res = op1 + op2;
            overflow = ((~(op1 ^ ~op2)) & (op1 ^ res) & SIGN18);
            break;
            // XXX make provisions for logicals
    }
    
    // now let's set some flags...
    
    // carry
    // NB: CARRY is not an overflow!
    
    if (flagsToSet & I_CARRY)
    {
        /* const */ bool carry = (res > 0777777);
if (op == '-') carry = ! carry; // XXX CAC black magic
        if (carry)
            SETF(*flags, I_CARRY);
        else
            CLRF(*flags, I_CARRY);
    }
    
    
    
    /*
     oVerflow rules .....
     
     oVerflow occurs for addition if the operands have the
     same sign and the result has a different sign. MSB(a) = MSB(b) and MSB(r) <> MSB(a)
     
     oVerflow occurs for subtraction if the operands have
     different signs and the sign of the result is different from the
     sign of the first operand. MSB(a) <> MSB(b) and MSB(r) <> MSB(a)
     */
    if (flagsToSet & I_OFLOW)
    {
        if (overflow)
            SETF(*flags, I_OFLOW);      // overflow
    }
    
    if (flagsToSet & I_ZERO)
    {
        if ((res & MASK18) == 0)
            SETF(*flags, I_ZERO);       // zero result
        else
            CLRF(*flags, I_ZERO);
    }
    
    if (flagsToSet & I_NEG)
    {
        if (res & SIGN18)            // if negative (things seem to want this even if unsigned ops)
            SETF(*flags, I_NEG);
        else
            CLRF(*flags, I_NEG);
    }
    
    if (flagsToSet & I_OFLOW)
    {
        if (overflow && ! TSTF (*flags, I_OMASK))
        {
            doFault(overflow_fault, 0,"addsub18b overflow fault");
        }
    }

    return res & MASK18;           // 32 => 18-bit. Mask off unnecessary bits ...
}

// XXX ticket #3 isSigned
// CANFAULT
word72 AddSub72b(char op, bool __attribute__((unused)) isSigned, word72 op1, word72 op2, word18 flagsToSet, word18 *flags)
{
    word72 res = 0;
    op1 &= ZEROEXT72;
    op2 &= ZEROEXT72;
    
    // perform requested operation
    bool overflow = false;
    
    switch (op)
    {
        case '+':
            res = op1 + op2;
            overflow = ((~(op1 ^ op2)) & (op1 ^ res) & SIGN72);
            break;
        case '-':
            res = op1 - op2;
            overflow = ((~(op1 ^ ~op2)) & (op1 ^ res) & SIGN72);
            break;
            // XXX make provisions for logicals
    }
    
    // now let's set some flags...
    
    // carry
    // NB: CARRY is not an overflow!
    
    if (flagsToSet & I_CARRY)
    {
        /* const */ bool carry = (res > MASK72);
if (op == '-') carry = ! carry; // XXX CAC black magic
        if (carry)
            SETF(*flags, I_CARRY);
        else
            CLRF(*flags, I_CARRY);
    }

    if (flagsToSet & I_OFLOW)
    {
        if (overflow)
            SETF(*flags, I_OFLOW);      // overflow
    }
    
    if (flagsToSet & I_ZERO)
    {
        if ((res & MASK72) == 0)
            SETF(*flags, I_ZERO);       // zero result
        else
            CLRF(*flags, I_ZERO);
    }
    
    if (flagsToSet & I_NEG)
    {
        if (res & SIGN72)            // if negative (things seem to want this even if unsigned ops)
            SETF(*flags, I_NEG);
        else
            CLRF(*flags, I_NEG);
    }
    
    if (flagsToSet & I_OFLOW)
    {
        if (overflow)
        {
            doFault(overflow_fault, 0,"addsub72 overflow fault");
        }
    }
    
    return res & MASK72;           // 128 => 72-bit. Mask off unnecessary bits ...
}

// CANFAULT
word36 compl36(word36 op1, word18 *flags)
{
    //printf("op1 = %llo %llo\n", op1, (-op1) & DMASK);
    
    op1 &= DMASK;
    
    word36 res = -op1 & DMASK;
    
    const bool ovr = op1 == MAXNEG;
    if (ovr)
        SETF(*flags, I_OFLOW);
    if (res & SIGN36)
        SETF(*flags, I_NEG);
    else
        CLRF(*flags, I_NEG);
    
    if (res == 0)
        SETF(*flags, I_ZERO);
    else
        CLRF(*flags, I_ZERO);
    
    if (ovr && ! TSTF (*flags, I_OMASK))
    {
        doFault(overflow_fault, 0,"compl36 overflow fault");
    }

    return res;
}

// CANFAULT
word18 compl18(word18 op1, word18 *flags)
{
    //printf("op1 = %llo %llo\n", op1, (-op1) & DMASK);
    
    op1 &= MASK18;
    
    word18 res = -op1 & MASK18;
    
    const bool ovr = op1 == MAX18NEG;
    if (ovr)
        SETF(*flags, I_OFLOW);
    if (res & SIGN18)
        SETF(*flags, I_NEG);
    else
        CLRF(*flags, I_NEG);
    
    if (res == 0)
        SETF(*flags, I_ZERO);
    else
        CLRF(*flags, I_ZERO);
    
    if (ovr && ! TSTF (*flags, I_OMASK))
        doFault(overflow_fault, 0,"compl18 overflow fault");

    return res;
}

void copyBytes(int posn, word36 src, word36 *dst)
{
    word36 mask = 0;
    
    if (posn & 8) // bit 30 - byte 0 - (bits 0-8)
        mask |= 0777000000000LL;
   
    if (posn & 4) // bit 31 - byte 1 - (bits 9-17)
        mask |= 0000777000000LL;
    
    if (posn & 2) // bit 32 - byte 2 - (bits 18-26)
        mask |= 0000000777000LL;
    
    if (posn & 1) // bit 33 - byte 3 - (bits 27-35)
        mask |= 0000000000777LL;
         
    word36 byteVals = src & mask;   // get byte bits
    
    // clear the bits in dst
    *dst &= ~mask;
    
    // and set the bits in dst
    *dst |= byteVals;
}


word9 getByte(int posn, word36 src)
{
    // XXX what's wrong with the macro????
    // XXX NB different parameter order
//    word36 mask = 0;
    
//    switch (posn)
//    {
//        case 0: // byte 0 - (bits 0-8)
//            mask |= 0777000000000LL;
//            break;
//        case 1: // byte 1 - (bits 9-17)
//            mask |= 0000777000000LL;
//            break;
//        case 2: // byte 2 - (bits 18-26)
//            mask |= 0000000777000LL;
//            break;
//        case 3: // byte 3 - (bits 27-35)
//            mask |= 0000000000777LL;
//            break;
//    }
    word9 byteVal = (word9) (src >> (9 * (3 - posn))) & 0777;   ///< get byte bits
    return byteVal;
}

void copyChars(int posn, word36 src, word36 *dst)
{
    word36 mask = 0;
    
    if (posn & 32) // bit 30 - char 0 - (bits 0-5)
        mask |= 0770000000000LL;
    
    if (posn & 16) // bit 31 - char 1 - (bits 6-11)
        mask |= 0007700000000LL;
    
    if (posn & 8) // bit 32 - char 2 - (bits 12-17)
        mask |= 0000077000000LL;
    
    if (posn & 4) // bit 33 - char 3 - (bits 18-23)
        mask |= 0000000770000LL;
    
    if (posn & 2) // bit 34 - char 4 - (bits 24-29)
        mask |= 0000000007700LL;
    
    if (posn & 1) // bit 35 - char 5 - (bits 30-35)
        mask |= 0000000000077LL;
    
    word36 byteVals = src & mask;   // get byte bits
    
    // clear the bits in dst
    *dst &= ~mask;
    
    // and set the bits in dst
    *dst |= byteVals;
    
}


/*!
 * write 9-bit byte into 36-bit word....
 */
void putByte(word36 *dst, word9 data, int posn)
{
    // XXX which is faster switch() or calculation?
    
    int offset = 27 - (9 * posn);//    0;
//    switch (posn)
//    {
//        case 0:
//            offset = 27;
//            break;
//        case 1:
//            offset = 18;
//            break;
//        case 2:
//            offset = 9;
//            break;
//        case 3:
//            offset = 0;
//            break;
//    }
    *dst = bitfieldInsert36(*dst, (word36)data, offset, 9);
}

void putChar(word36 *dst, word6 data, int posn)
{
    // XXX which is faster switch() or calculation?
    
    int offset = 30 - (6 * posn);   //0;
//    switch (posn)
//    {
//        case 0:
//            offset = 30;
//            break;
//        case 1:
//            offset = 24;
//            break;
//        case 2:
//            offset = 18;
//            break;
//        case 3:
//            offset = 12;
//            break;
//        case 4:
//            offset = 6;
//            break;
//        case 5:
//            offset = 0;
//            break;
//    }
    *dst = bitfieldInsert36(*dst, (word36)data, offset, 6);
}

word72 convertToWord72(word36 even, word36 odd)
{
    return ((word72)even << 36) | (word72)odd;
}

void convertToWord36(word72 src, word36 *even, word36 *odd)
{
    *even = (word36)(src >> 36) & DMASK;
    *odd = (word36)src & DMASK;
}

//! XXX the following compare routines probably need sign extension
void cmp36(word36 oP1, word36 oP2, word18 *flags)
{
    word36s op1 = (word36s) SIGNEXT36(oP1 & DMASK);
    word36s op2 = (word36s) SIGNEXT36(oP2 & DMASK);
    
    if (!((word36)op1 & SIGN36) && ((word36)op2 & SIGN36) && (op1 > op2))
        CLRF(*flags, I_ZERO | I_NEG | I_CARRY);
    else if (((word36)op1 & SIGN36) == ((word36)op2 & SIGN36) && (op1 > op2))
    {
        SETF(*flags, I_CARRY);
        CLRF(*flags, I_ZERO | I_NEG);
    } else if ((((word36)op1 & SIGN36) == ((word36)op2 & SIGN36)) && (op1 == op2))
    {
        SETF(*flags, I_ZERO | I_CARRY);
        CLRF(*flags, I_NEG);
    } else if ((((word36)op1 & SIGN36) == ((word36)op2 & SIGN36)) && (op1 < op2))
    {
        SETF(*flags, I_NEG);
        CLRF(*flags, I_ZERO | I_CARRY);
    } else if ((((word36)op1 & SIGN36) && !((word36)op2 & SIGN36)) && (op1 < op2))
    {
        SETF(*flags, I_CARRY | I_NEG);
        CLRF(*flags, I_ZERO);
    }
}
void cmp18(word18 oP1, word18 oP2, word18 *flags)
{
    word18s op1 = (word18s) SIGNEXT18(oP1 & MASK18);
    word18s op2 = (word18s) SIGNEXT18(oP2 & MASK18);

    if (!((word18)op1 & SIGN18) && ((word18)op2 & SIGN18) && (op1 > op2))
        CLRF(*flags, I_ZERO | I_NEG | I_CARRY);
    else if (((word18)op1 & SIGN18) == ((word18)op2 & SIGN18) && (op1 > op2))
    {
        SETF(*flags, I_CARRY);
        CLRF(*flags, I_ZERO | I_NEG);
    } else if ((((word18)op1 & SIGN18) == ((word18)op2 & SIGN18)) && (op1 == op2))
    {
        SETF(*flags, I_ZERO | I_CARRY);
        CLRF(*flags, I_NEG);
    } else if ((((word18)op1 & SIGN18) == ((word18)op2 & SIGN18)) && (op1 < op2))
    {
        SETF(*flags, I_NEG);
        CLRF(*flags, I_ZERO | I_CARRY);
    } else if ((((word18)op1 & SIGN18) && !((word18)op2 & SIGN18)) && (op1 < op2))
    {
        SETF(*flags, I_CARRY | I_NEG);
        CLRF(*flags, I_ZERO);
    }
}
void cmp36wl(word36 A, word36 Y, word36 Q, word18 *flags)
{
    // This is wrong; signed math is needed.

    //bool Z = (A <= Y && Y <= Q) || (A >= Y && Y >= Q);

    word36s As = (word36s) SIGNEXT36(A & DMASK);
    word36s Ys = (word36s) SIGNEXT36(Y & DMASK);
    word36s Qs = (word36s) SIGNEXT36(Q & DMASK);
    bool Z = (As <= Ys && Ys <= Qs) || (As >= Ys && Ys >= Qs);

    SCF(Z, *flags, I_ZERO);
    
    if (!(Q & SIGN36) && (Y & SIGN36) && (Qs > Ys))
        CLRF(*flags, I_NEG | I_CARRY);
    else if (((Q & SIGN36) == (Y & SIGN36)) && (Qs >= Ys))
    {
        SETF(*flags, I_CARRY);
        CLRF(*flags, I_NEG);
    } else if (((Q & SIGN36) == (Y & SIGN36)) && (Qs < Ys))
    {
        CLRF(*flags, I_CARRY);
        SETF(*flags, I_NEG);
    } else if ((Q & SIGN36) && !(Y & SIGN36) && (Qs < Ys))
        SETF(*flags, I_NEG | I_CARRY);
}

void cmp72(word72 op1, word72 op2, word18 *flags)
{
   // The case of op1 == 400000000000000000000000 and op2 == 0 falls through
   // this code.
#if 0
    if (!(op1 & SIGN72) && (op2 & SIGN72) && (op1 > op2))
        CLRF(*flags, I_ZERO | I_NEG | I_CARRY);
    else if ((op1 & SIGN72) == (op2 & SIGN72) && (op1 > op2))
    {
        SETF(*flags, I_CARRY);
        CLRF(*flags, I_ZERO | I_NEG);
    } else if (((op1 & SIGN72) == (op2 & SIGN72)) && (op1 == op2))
    {
        SETF(*flags, I_ZERO | I_CARRY);
        CLRF(*flags, I_NEG);
    } else if (((op1 & SIGN72) == (op2 & SIGN72)) && (op1 < op2))
    {
        SETF(*flags, I_NEG);
        CLRF(*flags, I_ZERO | I_CARRY);
    } else if (((op1 & SIGN72) && !(op2 & SIGN72)) && (op1 < op2))
    {
        SETF(*flags, I_CARRY | I_NEG);
        CLRF(*flags, I_ZERO);
    }
#else
    word72s op1s = (word72s) SIGNEXT72 (op1 & MASK72);
    word72s op2s = (word72s) SIGNEXT72 (op2 & MASK72);
    if (op1s > op2s)
      {
        if (op2 & SIGN72)
          CLRF (* flags, I_CARRY);
        else
          SETF (* flags, I_CARRY);
        CLRF (* flags, I_ZERO | I_NEG);
      }
    else if (op1s == op2s)
      {
        SETF (* flags, I_CARRY | I_ZERO);
        CLRF (* flags, I_NEG);
      }
    else /* op1s < op2s */
      {
        if (op1 & SIGN72)
          SETF (* flags, I_CARRY);
        else
          CLRF (* flags, I_CARRY);
        CLRF (* flags, I_ZERO);
        SETF (* flags, I_NEG);
      }


#endif
}

/*
 * String utilities ...
 */

/* ------------------------------------------------------------------------- */

char * strlower(char *q)
{
	char *s = q;
    
	while (*s) {
		if (isupper(*s))
			*s = (char) tolower(*s);
		s++;
	}
	return q;
}

/* ------------------------------------------------------------------------- */

/*  state definitions  */
#define	STAR	0
#define	NOTSTAR	1
#define	RESET	2

int strmask(char *str, char *mask)
/*!
 Tests string 'str' against mask string 'mask'
 Returns TRUE if the string matches the mask.
 
 The mask can contain '?' and '*' wild card characters.
 '?' matches any	single character.
 '*' matches any number of any characters.
 
 For example:
 strmask("Hello", "Hello");	---> TRUE
 strmask("Hello", "Jello");	---> FALSE
 strmask("Hello", "H*o");	---> TRUE
 strmask("Hello", "H*g");	---> FALSE
 strmask("Hello", "?ello");	---> TRUE
 strmask("Hello", "H????");	---> TRUE
 strmask("H", "H????");		---> FALSE
 */
{
	char *sp, *mp, *reset_string, *reset_mask, *sn;
	int state;
    
	sp = str;
	mp = mask;
    
	while (1) {
		switch (*mp) {
            case '\0':
                return(*sp ? false : true);
            case '?':
                sp++;
                mp++;
                break;
            default:
                if (*mp == *sp) {
                    sp++;
                    mp++;
                    break;
                } else {
                    return(false);
                }
            case '*':
                if (*(mp + 1) == '\0') {
                    return(true);
                }
                if ((sn = strchr(sp, *(mp + 1))) == NULL) {
                    return(false);
                }
                
                /* save place -- match rest of string */
                /* if fail, reset to here */
                reset_mask = mp;
                reset_string = sn + 1;
                
                mp = mp + 2;
                sp = sn + 1;
                state = NOTSTAR;
                while (state == NOTSTAR) {
                    switch (*mp) {
                        case '\0':
                            if (*sp == '\0')
                                return(false);
                            else
                                state = RESET;
                            break;
                        case '?':
                            sp++;
                            mp++;
                            break;
                        default:
                            if (*mp == *sp) {
                                sp++;
                                mp++;
                            } else
                                state = RESET;
                            break;
                        case '*':
                            state = STAR;
                            break;
                    }
                }
                /* we've reach a new star or should reset to last star */
                if (state == RESET) {
                    sp = reset_string;
                    mp = reset_mask;
                }
                break;
		}
	}
	return(true);
}

/*!
 a - Bitfield to insert bits into.
 b - Bit pattern to insert.
 c - Bit offset number.
 d = Number of bits to insert.
 
 Description
 
 Returns the result of inserting bits B at offset C of length D in the bitfield A.
 */
word72 bitfieldInsert72(word72 a, word72 b, int c, int d)
{
    word72 mask = ~((word72)-1 << d) << c;
    mask = ~mask;
    a &= mask;
    return a | (b << c);
}

/*!
 a - Bitfield to insert bits into.
 b - Bit pattern to insert.
 c - Bit offset number.
 d = Number of bits to insert.
 
 Description
 
 Returns the result of inserting bits B at offset C of length D in the bitfield A.
 
 XXX: c & d should've been expressed in dps8 big-endian rather than little-endian numbering. Oh, well.
 
 */
word36 bitfieldInsert36(word36 a, word36 b, int c, int d)
{
    word36 mask = ~(0xffffffffffffffffLL << d) << c;
    mask = ~mask;
    a &= mask;
    return a | (b << c);
}


/*!
a - Bitfield to insert bits into.
b - Bit pattern to insert.
c - Bit offset number.
d = Number of bits to insert.
 
 Description
 
 Returns the result of inserting bits B at offset C of length D in the bitfield A.
*/
int bitfieldInsert(int a, int b, int c, int d)
{
    uint32 mask = ~(0xffffffff << d) << c;
    mask = ~mask;
    a &= mask;
    return a | (b << c);
}

/*!
 a -  Bitfield to extract bits from.
 b -  Bit offset number. Bit offsets start at 0.
 c - Number of bits to extract.
 
 Description
 
 Returns bits from offset b of length c in the bitfield a.
 */
int bitfieldExtract(int a, int b, int c)
{
    int mask = ~((int)0xffffffff << c);
    if (b > 0)
        return (a >> b) & mask; // original pseudocode had b-1
    else
        return a & mask;
}
/*!
 a -  Bitfield to extract bits from.
 b -  Bit offset number. Bit offsets start at 0.
 c - Number of bits to extract.
 
 Description
 
 Returns bits from offset b of length c in the bitfield a.
 NB: This would've been much easier to use of I changed, 'c', the bit offset to reflect the dps8s 36bit word!! Oh, well.

 */
word36 bitfieldExtract36(word36 a, int b, int c)
{
    word36 mask = ~(0xffffffffffffffffLL  << c);
    //printf("mask=%012llo\n", mask);
    if (b > 0)
        return (a >> b) & mask; // original pseudocode had b-1
    else
        return a & mask;
}
word72 bitfieldExtract72(word72 a, int b, int c)
{
    word72 mask = ~((word72)-1 << c);
    if (b > 0)
        return (a >> b) & mask; // original pseudocode had b-1
    else
        return a & mask;
}

#ifndef QUIET_UNUSED
/*!
 @param[in] x Bitfield to count bits in.
 
 \brief Returns the count of set bits (value of 1) in the bitfield x.
 */
int bitCount(int x)
{
    int i;
    int res = 0;
    for(i = 0; i < 32; i++) {
        uint32 mask = 1 << i;
        if (x & (int) mask)
            res ++;
    }
    return res;
}
#endif 

#ifndef QUIET_UNUSED
/*!
 @param[in] x Bitfield to find LSB in.
 
 \brief Returns the bit number of the least significant bit (value of 1) in the bitfield x. If no bits have the value 1 then -1 is returned.
 */
int findLSB(int x)
{
    int i;
    int mask;
    int res = -1;
    for(i = 0; i < 32; i++) {
        mask = 1 << i;
        if (x & mask) {
            res = i;
            break;
        }
    }
    return res;
}
#endif


#ifndef QUIET_UNUSED
/*!
 @param[in] x  Bitfield to find MSB in.
 
 \brief Returns the bit number of the most significant bit (value of 1) in the bitfield x. If the number is negative then the position of the first zero bit is returned. If no bits have the value 1 (or 0 in the negative case) then -1 is returned.

 from http://http.developer.nvidia.com/Cg/findMSB.html

 NB: the above site provides buggy "pseudocode". >sheesh<
 
 */
int findMSB(int x)
{
    int i;
    int mask;
    int res = -1;
    if (x < 0) x = ~x;
    for(i = 0; i < 32; i++) {
        mask = (int) 0x80000000 >> i;
        if (x & mask) {
            res = 31 - i;
            break;
        }
    }
    return res;
}
#endif

#ifndef QUIET_UNUSED
/*!
 @param[in] x Bitfield to reverse.
 
 \brief Returns the reverse of the bitfield x.
 */
int bitfieldReverse(int x)
{
    int res = 0;
    int i, shift, mask;
    
    for(i = 0; i < 32; i++) {
        mask = 1 << i;
        shift = 32 - 2*i - 1;
        mask &= x;
        mask = (shift > 0) ? mask << shift : mask >> -shift;
        res |= mask;
    }
    
    return res;
}
#endif


//#define MASKBITS(x) ( ~(~((t_uint64)0)<<x) ) // lower (x) bits all ones

/*
 * getbits36()
 *
 * Extract a range of bits from a 36-bit word.
 */

inline word36 getbits36(word36 x, uint i, uint n) {
    // bit 35 is right end, bit zero is 36th from the right
    int shift = 35-(int)i-(int)n+1;
    if (shift < 0 || shift > 35) {
        sim_printf ("getbits36: bad args (%012llo,i=%d,n=%d)\n", x, i, n);
        return 0;
    } else
        return (x >> (unsigned) shift) & ~ (~0U << n);
}

// ============================================================================

/*
 * setbits36()
 *
 * Set a range of bits in a 36-bit word -- Returned value is x with n bits
 * starting at p set to the n lowest bits of val
 */

inline word36 setbits36(word36 x, uint p, uint n, word36 val)
{
    int shift = 36 - (int) p - (int) n;
    if (shift < 0 || shift > 35) {
        sim_printf ("setbits36: bad args (%012llo,pos=%d,n=%d)\n", x, p, n);
        return 0;
    }
    word36 mask = ~ (~0U<<n);  // n low bits on
    mask <<= (unsigned) shift;  // shift 1s to proper position; result 0*1{n}0*
    // caller may provide val that is too big, e.g., a word with all bits
    // set to one, so we mask val
    word36 result = (x & ~ mask) | ((val&MASKBITS(n)) << (36 - p - n));
    return result;
}


// ============================================================================

/*
 * putbits36()
 *
 * Set a range of bits in a 36-bit word -- Sets the bits in the argument,
 * starting at p set to the n lowest bits of val
 */

inline void putbits36 (word36 * x, uint p, uint n, word36 val)
  {
    int shift = 36 - (int) p - (int) n;
    if (shift < 0 || shift > 35)
      {
        sim_printf ("putbits36: bad args (%012llo,pos=%d,n=%d)\n", * x, p, n);
        return;
      }
    word36 mask = ~ (~0U << n);  // n low bits on
    mask <<= (unsigned) shift;  // shift 1s to proper position; result 0*1{n}0*
    // caller may provide val that is too big, e.g., a word with all bits
    // set to one, so we mask val
    * x = (* x & ~mask) | ((val & MASKBITS (n)) << (36 - p - n));
    return;
  }



/*
 * bin2text()
 *
 * Display as bit string.
 * WARNING: returns pointer of two alternating static buffers
 *
 */

#include <ctype.h>

char *bin2text(t_uint64 word, int n)
{
    // WARNING: static buffer
    static char str1[65];
    static char str2[65];
    static char *str = NULL;
    if (str == NULL)
        str = str1;
    else if (str == str1)
        str = str2;
    else
        str = str1;
    str[n] = 0;
    int i;
    for (i = 0; i < n; ++ i) {
        str[n-i-1] = ((word % 2) == 1) ? '1' : '0';
        word >>= 1;
    }
    return str;
}

#include <ctype.h>

#if 0
//
// simh puts the tty in raw mode when the sim is running;
// this means that test output to the console will lack CR's and
// be all messed up.
//
// There are three ways around this:
//   1: switch back to cooked mode for the message
//   2: walk the message and output CRs before LFs with sim_putchar()
//   3: walk the message and output CRs before LFs with sim_os_putchar()
//
// The overhead and obscure side effects of switching are unknown.
//
// sim_putchar adds the text to the log file, but not the debug file; and
// sim_putchar puts the CRs into the log file.
//
// sim_os_putchar skips checks that sim_putchar does that verify that
// we are actually talking to tty, instead of a telnet connection or other
// non-tty thingy.
//
// USE_COOKED does the wrong thing when stdout is piped; ie not a terminal

//#define USE_COOKED
#define USE_PUTCHAR

void sim_printf( const char * format, ... )
{
    char buffer[4096];
    
    va_list args;
    va_start (args, format);
    vsnprintf (buffer, sizeof(buffer), format, args);
    
#ifdef USE_COOKED
    if (sim_is_running)
      sim_ttcmd ();
#endif

    for(uint i = 0 ; i < sizeof(buffer); i += 1)
    {
        if (buffer[i]) {
#ifdef USE_PUTCHAR
            if (sim_is_running && buffer [i] == '\n')
              sim_putchar ('\r');
#endif
#ifdef USE_OS_PUTCHAR
            if (sim_is_running && buffer [i] == '\n')
              sim_os_putchar ('\r');
#endif
            sim_putchar(buffer[i]);
            //if (sim_deb)
              //fputc (buffer [i], sim_deb);
        } else
            break;
    }
 
#ifdef USE_COOKED
    if (sim_is_running)
      sim_ttrun ();
#endif

    va_end (args);
}
#endif

// Rework sim_printf.
//
// Distinguish between the console device and the window in which dps8 is
// running.
//
// There are (up to) three outputs:
//
//   - the window in which dps8 is running (stdout)
//   - the log file (which may be stdout or stderr)
//   - the console device
//
// sim_debug --
//   prints time stamped strings to the logfile.
// sim_printf --
//   prints strings to logfile and stdout
// sim_putchar/sim_os_putchar/sim_puts
//   prints char/string to the console

void sim_printf (const char * format, ...)
  {
    char buffer [4096];
    bool bOut = (sim_deb ? fileno (sim_deb) != fileno (stdout) : true);

    va_list args;
    va_start (args, format);
    vsnprintf (buffer, sizeof (buffer), format, args);
    
    for (uint i = 0 ; i < sizeof (buffer); i ++)
      {
        if (! buffer [i])
          break;

        // stdout

        if (bOut)
          {
            if (sim_is_running && buffer [i] == '\n')
              putchar  ('\r');
            putchar (buffer [i]);
          }

        // logfile

        if (sim_deb)
          {
            if (sim_is_running && buffer [i] == '\n')
              fputc  ('\r', sim_deb);
            fputc (buffer [i], sim_deb);
          }
    }
    va_end (args);
    fflush (sim_deb);
    if (bOut)
      fflush (stdout);
}

void sim_puts (char * str)
  {
    char * p = str;
    while (* p)
      sim_putchar (* (p ++));
  }

// XXX what about config=addr7=123, where clist has a "addr%"?

// return -2: error; -1: done; >= 0 option found
int cfgparse (const char * tag, char * cptr, config_list_t * clist, config_state_t * state, int64_t * result)
  {
    if (! cptr)
      return -2;
    char * start = NULL;
    if (! state -> copy)
      {
        state -> copy = strdup (cptr);
        start = state -> copy;
        state ->  statement_save = NULL;
      }

    int ret = -2; // error

    // grab every thing up to the next semicolon
    char * statement;
    statement = strtok_r (start, ";", & state -> statement_save);
    start = NULL;
    if (! statement)
      {
        ret = -1; // done
        goto done;
      }

    // extract name
    char * name_start = statement;
    char * name_save = NULL;
    char * name;
    name = strtok_r (name_start, "=", & name_save);
    if (! name)
      {
        sim_printf ("error: %s: can't parse name\n", tag);
        goto done;
      }

    // lookup name
    config_list_t * p = clist;
    while (p -> name)
      {
        if (strcasecmp (name, p -> name) == 0)
          break;
        p ++;
      }
    if (! p -> name)
      {
        sim_printf ("error: %s: don't know name <%s>\n", tag, name);
        goto done;
      }

    // extract value
    char * value;
    value = strtok_r (NULL, "", & name_save);
    if (! value)
      {
        // Special case; min>max and no value list
        // means that a missing value is ok
        if (p -> min > p -> max && ! p -> value_list)
          {
            return (int) (p - clist);
          }
        sim_printf ("error: %s: can't parse value\n", tag);
        goto done;
      }

    // first look to value in the value list
    config_value_list_t * v = p -> value_list;
    if (v)
      {
        while (v -> value_name)
          {
            if (strcasecmp (value, v -> value_name) == 0)
              break;
            v ++;
          }

        // Hit?
        if (v -> value_name)
          {
            * result = v -> value;
            return (int) (p - clist);
          }
      }

    // Must be a number

    if (p -> min > p -> max)
      {
        sim_printf ("error: %s: can't parse value\n", tag);
        goto done;
      }

    if (strlen (value) == 0)
      {
         sim_printf ("error: %s: missing value\n", tag);
         goto done;
      }
    char * endptr;
    int64_t n = strtoll (value, & endptr, 0);
    if (* endptr)
      {
        sim_printf ("error: %s: can't parse value\n", tag);
        goto done;
      } 

// XXX small bug; doesn't check for junk after number...
    if (n < p -> min || n > p -> max)
      {
        sim_printf ("error: %s: value out of range\n", tag);
        goto done;
      } 
    
    * result = n;
    return (int) (p - clist);

done:
    free (state -> copy);
    state -> copy= NULL;
    return ret;
  }

void cfgparse_done (config_state_t * state)
  {
    if (state -> copy)
      free (state -> copy);
    state -> copy = NULL;
  }

// strdup with limited C-style escape processing
//
//  strdupesc ("foo\nbar") --> 'f' 'o' 'o' 012 'b' 'a' 'r'
//
//  Handles:
//   \\
//   \n
//   \t
//   \f
//   \r
//
// \\ doesn't seem to work...
//  Also, a simh specific:
//
//   \e   (end simulation)
//
//  the simh parser doesn't handle these very well...
//
//   \_  space
//   \c  comma
//   \s  semicolon
//   \d  dollar
//   \w  \
//
//  all others silently ignored and left unprocessed
//

char * strdupesc (const char * str)
  {
    char * buf = strdup (str);
    char * p = buf;
    while (* p)
      {
        if (* p != '\\')
          {
            p ++;
            continue;
          }
        if (p [1] == '\\')
          * p = '\\';
        else if (p [1] == 'w')
          * p = '\\';
        else if (p [1] == 'n')
          * p = '\n';
        else if (p [1] == 't')
          * p = '\t';
        else if (p [1] == 'f')
          * p = '\f';
        else if (p [1] == 'r')
          * p = '\r';
        else if (p [1] == 'e')
          * p = '\005';
        else if (p [1] == '_')
          * p = ' ';
        else if (p [1] == 'c')
          * p = ',';
        else if (p [1] == 's')
          * p = ';';
        else if (p [1] == 's')
          * p = '$';
        else
          {
            p ++;
            continue;
          }
        p ++;
//sim_printf ("was <%s>\n", buf);
        memmove (p, p + 1, strlen (p + 1) + 1);
//sim_printf ("is  <%s>\n", buf);
      }
    return buf;
  }



// Layout of data as read from simh tape format
//
//   bits: buffer of bits from a simh tape. The data is
//   packed as 2 36 bit words in 9 eight bit bytes (2 * 36 == 7 * 9)
//   The of the bytes in bits is
//      byte     value
//       0       most significant byte in word 0
//       1       2nd msb in word 0
//       2       3rd msb in word 0
//       3       4th msb in word 0
//       4       upper half is 4 least significant bits in word 0
//               lower half is 4 most significant bit in word 1
//       5       5th to 13th most signicant bits in word 1
//       6       ...
//       7       ...
//       8       least significant byte in word 1
//

// Multics humor: this is idiotic


// Data conversion routines
//
//  'bits' is the packed bit stream read from the simh tape
//    it is assumed to start at an even word36 address
//
//   extr36
//     extract the word36 at woffset
//

word36 extr36 (uint8 * bits, uint woffset)
  {
    uint isOdd = woffset % 2;
    uint dwoffset = woffset / 2;
    uint8 * p = bits + dwoffset * 9;

    t_uint64 w;
    if (isOdd)
      {
        w  = ((t_uint64) (p [4] & 0xf)) << 32;
        w |=  (t_uint64) (p [5]) << 24;
        w |=  (t_uint64) (p [6]) << 16;
        w |=  (t_uint64) (p [7]) << 8;
        w |=  (t_uint64) (p [8]);
      }
    else
      {
        w  =  (t_uint64) (p [0]) << 28;
        w |=  (t_uint64) (p [1]) << 20;
        w |=  (t_uint64) (p [2]) << 12;
        w |=  (t_uint64) (p [3]) << 4;
        w |= ((t_uint64) (p [4]) >> 4) & 0xf;
      }
    // mask shouldn't be neccessary but is robust
    return (word36) (w & 0777777777777ULL);
  }

void put36 (word36 val, uint8 * bits, uint woffset)
  {
    uint isOdd = woffset % 2;
    uint dwoffset = woffset / 2;
    uint8 * p = bits + dwoffset * 9;

    if (isOdd)
      {
        p [4] &=               0xf0;
        p [4] |= (val >> 32) & 0x0f;
        p [5]  = (val >> 24) & 0xff;
        p [6]  = (val >> 16) & 0xff;
        p [7]  = (val >>  8) & 0xff;
        p [8]  = (val >>  0) & 0xff;
        //w  = ((t_uint64) (p [4] & 0xf)) << 32;
        //w |=  (t_uint64) (p [5]) << 24;
        //w |=  (t_uint64) (p [6]) << 16;
        //w |=  (t_uint64) (p [7]) << 8;
        //w |=  (t_uint64) (p [8]);
      }
    else
      {
        p [0]  = (val >> 28) & 0xff;
        p [1]  = (val >> 20) & 0xff;
        p [2]  = (val >> 12) & 0xff;
        p [3]  = (val >>  4) & 0xff;
        p [4] &=               0x0f;
        p [4] |= (val <<  4) & 0xf0;
        //w  =  (t_uint64) (p [0]) << 28;
        //w |=  (t_uint64) (p [1]) << 20;
        //w |=  (t_uint64) (p [2]) << 12;
        //w |=  (t_uint64) (p [3]) << 4;
        //w |= ((t_uint64) (p [4]) >> 4) & 0xf;
      }
    // mask shouldn't be neccessary but is robust
  }

//
//   extr9
//     extract the word9 at coffset
//
//   | 012345678 | 012345678 |012345678 | 012345678 | 012345678 | 012345678 | 012345678 | 012345678 |
//     0       1          2         3          4          5          6          7          8
//     012345670   123456701  234567012   345670123   456701234   567012345   670123456   701234567  
//

word9 extr9 (uint8 * bits, uint coffset)
  {
    uint charNum = coffset % 8;
    uint dwoffset = coffset / 8;
    uint8 * p = bits + dwoffset * 9;

    word9 w;
    switch (charNum)
      {
        case 0:
          w = ((((word9) p [0]) << 1) & 0776) | ((((word9) p [1]) >> 7) & 0001);
          break;
        case 1:
          w = ((((word9) p [1]) << 2) & 0774) | ((((word9) p [2]) >> 6) & 0003);
          break;
        case 2:
          w = ((((word9) p [2]) << 3) & 0770) | ((((word9) p [3]) >> 5) & 0007);
          break;
        case 3:
          w = ((((word9) p [3]) << 4) & 0760) | ((((word9) p [4]) >> 4) & 0017);
          break;
        case 4:
          w = ((((word9) p [4]) << 5) & 0740) | ((((word9) p [5]) >> 3) & 0037);
          break;
        case 5:
          w = ((((word9) p [5]) << 6) & 0700) | ((((word9) p [6]) >> 2) & 0077);
          break;
        case 6:
          w = ((((word9) p [6]) << 7) & 0600) | ((((word9) p [7]) >> 1) & 0177);
          break;
        case 7:
          w = ((((word9) p [7]) << 8) & 0400) | ((((word9) p [8]) >> 0) & 0377);
          break;
      }
    // mask shouldn't be neccessary but is robust
    return w & 0777U;
  }

//
//   extr18
//     extract the word18 at coffset
//
//   |           11111111 |           11111111 |           11111111 |           11111111 |
//   | 012345678901234567 | 012345678901234567 | 012345678901234567 | 012345678901234567 |
//
//     0       1       2          3       4          5       6          7       8
//     012345670123456701   234567012345670123   456701234567012345   670123456701234567  
//
//     000000001111111122   222222333333334444   444455555555666666   667777777788888888
//
//       0  0  0  0  0  0     0  0  0  0  0  0     0  0  0  0  0  0     0  0  0  0  0  0
//       7  7  6  0  0  0     7  7  0  0  0  0     7  4  0  0  0  0     6  0  0  0  0  0
//       0  0  1  7  7  4     0  0  7  7  6  0     0  3  7  7  0  0     1  7  7  4  0  0
//       0  0  0  0  0  3     0  0  0  0  1  7     0  0  0  0  7  7     0  0  0  3  7  7

word18 extr18 (uint8 * bits, uint boffset)
  {
    uint byteNum = boffset % 4;
    uint dwoffset = boffset / 4;
    uint8 * p = bits + dwoffset * 18;

    word18 w;
    switch (byteNum)
      {
        case 0:
          w = ((((word18) p [0]) << 10) & 0776000) | ((((word18) p [1]) << 2) & 0001774) | ((((word18) p [2]) >> 6) & 0000003);
          break;
        case 1:
          w = ((((word18) p [2]) << 12) & 0770000) | ((((word18) p [3]) << 4) & 0007760) | ((((word18) p [4]) >> 4) & 0000017);
          break;
        case 2:
          w = ((((word18) p [4]) << 14) & 0740000) | ((((word18) p [5]) << 6) & 0037700) | ((((word18) p [6]) >> 2) & 0000077);
          break;
        case 3:
          w = ((((word18) p [6]) << 16) & 0600000) | ((((word18) p [7]) << 8) & 0177400) | ((((word18) p [8]) >> 0) & 0000377);
          break;
      }
    // mask shouldn't be neccessary but is robust
    return w & 0777777U;
  }

//
//  getbit
//     Get a single bit. offset can be bigger when word size
//

uint8 getbit (void * bits, int offset)
  {
    int offsetInWord = offset % 36;
    int revOffsetInWord = 35 - offsetInWord;
    int offsetToStartOfWord = offset - offsetInWord;
    int revOffset = offsetToStartOfWord + revOffsetInWord;

    uint8 * p = (uint8 *) bits;
    unsigned int byte_offset = revOffset / 8;
    unsigned int bit_offset = revOffset % 8;
    // flip the byte back
    bit_offset = 7 - bit_offset;

    uint8 byte = p [byte_offset];
    byte >>= bit_offset;
    byte &= 1;
    //printf ("offset %d, byte_offset %d, bit_offset %d, byte %x, bit %x\n", offset, byte_offset, bit_offset, p [byte_offset], byte);
    return byte;
  }

//
// extr
//    Get a string of bits (up to 64)
//

t_uint64 extr (void * bits, int offset, int nbits)
  {
    t_uint64 n = 0;
    int i;
    for (i = nbits - 1; i >= 0; i --)
      {
        n <<= 1;
        n |= getbit (bits, i + offset);
        //printf ("%012lo\n", n);
      }
    return n;
  }

int extractWord36FromBuffer (uint8 * bufp, t_mtrlnt tbc, uint * words_processed, t_uint64 *wordp)
  {
    uint wp = * words_processed; // How many words have been processed

    // 2 dps8m words == 9 bytes

    uint bytes_processed = (wp * 9 + 1) / 2;
    if (bytes_processed >= tbc)
      return 1;
    //sim_printf ("store 0%08lo@0%012llo\n", wordp - M, extr36 (bufp, wp));

    * wordp = extr36 (bufp, wp);
    //sim_printf ("* %06lo = %012llo\n", wordp - M, * wordp);
    (* words_processed) ++;

    return 0;
  }

int insertWord36toBuffer (uint8 * bufp, t_mtrlnt tbc, uint * words_processed, t_uint64 word)
  {
    uint wp = * words_processed; // How many words have been processed

    // 2 dps8m words == 9 bytes

    uint bytes_processed = (wp * 9 + 1) / 2;
    if (bytes_processed >= tbc)
      return 1;
    //sim_printf ("store 0%08lo@0%012llo\n", wordp - M, extr36 (bufp, wp));

    put36 (word, bufp, wp);
    //sim_printf ("* %06lo = %012llo\n", wordp - M, * wordp);
    (* words_processed) ++;

    return 0;
  }

static void print_uint128_r (__uint128_t n, char * p)
  {
    if (n == 0)
      return;

    print_uint128_r(n / 10, p);
    if (p)
      {
        char s [2];
        s [0] = n % 10 + '0';
        s [1] = '\0';
        strcat (p, s);
      }
    else
      sim_printf("%c", (int) (n%10+0x30));
  }

void print_int128 (__int128_t n, char * p)
  {
    if (n == 0)
      {
        if (p)
          strcat (p, "0");
        else
          sim_printf ("0");
        return;
      }
    if (n < 0)
      {
        if (p)
          strcat (p, "-");
        else
          sim_printf ("-");
        n = -n;
      }
    print_uint128_r ((__uint128_t) n, p);
  }

// Return simh's gtime as a long long.
uint64 sim_timell (void)
  {
    return (uint64) sim_gtime ();
  }

