t_stat Read (word18 addr, word36 *dat, _processor_cycle_type cyctyp, bool b29);
t_stat Write (word18 addr, word36 dat, _processor_cycle_type cyctyp, bool b29);

