extern UNIT TR_clk_unit [];
extern DEVICE clk_dev;


