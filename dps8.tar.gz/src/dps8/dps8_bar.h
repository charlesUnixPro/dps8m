word18 getBARaddress(word18 addr);


