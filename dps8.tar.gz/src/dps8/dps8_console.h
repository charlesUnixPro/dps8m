void console_init(void);
t_stat cable_opcon (int iom_unit_num, int chan_num);

