void mt_init(void);
t_stat cable_mt (int mt_unit_num, int iom_unit_num, int chan_num, int dev_code);
int get_mt_numunits (void);


