void disk_init(void);

