int read_simh_blk (int fd, void * buf, ssize_t buflen);

